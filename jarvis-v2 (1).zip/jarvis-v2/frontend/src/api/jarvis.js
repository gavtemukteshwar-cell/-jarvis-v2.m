import axios from 'axios'

const api = axios.create({ baseURL: '/api' })

// ── JARVIS AI ──
export const sendMessage = (messages, module = '') =>
  api.post('/jarvis/chat', { messages, module }).then(r => r.data)

// ── CHAT HISTORY ──
export const createSession = (title) =>
  api.post('/chat/sessions', { title }).then(r => r.data)

export const getSessions = () =>
  api.get('/chat/sessions').then(r => r.data)

export const deleteSession = (id) =>
  api.delete(`/chat/sessions/${id}`).then(r => r.data)

export const saveMessage = (session_id, role, content, module = '') =>
  api.post('/chat/messages', { session_id, role, content, module }).then(r => r.data)

export const getMessages = (session_id) =>
  api.get(`/chat/messages/${session_id}`).then(r => r.data)

export const updateSessionTitle = (id, title) =>
  api.patch(`/chat/sessions/${id}/title`, { title }).then(r => r.data)

// ── CALENDAR ──
export const getCalendarStatus = () =>
  api.get('/calendar/status').then(r => r.data)

export const getCalendarAuth = () =>
  api.get('/calendar/auth').then(r => r.data)

export const getEvents = (days = 7) =>
  api.get(`/calendar/events?days=${days}`).then(r => r.data)

export const getTodayEvents = () =>
  api.get('/calendar/today').then(r => r.data)

export const createEvent = (data) =>
  api.post('/calendar/events', data).then(r => r.data)

export const deleteEvent = (id) =>
  api.delete(`/calendar/events/${id}`).then(r => r.data)
