import React, { useState, useEffect, useCallback } from 'react'
import styled from 'styled-components'
import Header from './components/Header'
import ModuleBar from './components/ModuleBar'
import Sidebar from './components/Sidebar'
import ChatWindow from './components/ChatWindow'
import CalendarPanel from './components/CalendarPanel'
import {
  sendMessage, createSession, getSessions, deleteSession,
  saveMessage, getMessages, updateSessionTitle,
  getCalendarStatus, getCalendarAuth, getEvents
} from './api/jarvis'

const Layout = styled.div`
  height: 100vh; display: flex; flex-direction: column;
  position: relative; z-index: 1;
`
const Main = styled.div`
  flex: 1; display: flex; overflow: hidden;
`

export default function App() {
  const [sessions, setSessions] = useState([])
  const [activeSession, setActiveSession] = useState(null)
  const [messages, setMessages] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [module, setModule] = useState('')
  const [calendarConnected, setCalendarConnected] = useState(false)
  const [calendarEvents, setCalendarEvents] = useState([])
  const [showCalendar, setShowCalendar] = useState(false)

  // Load sessions on mount
  useEffect(() => {
    loadSessions()
    checkCalendar()

    // Check if returning from Google OAuth
    const params = new URLSearchParams(window.location.search)
    if (params.get('calendar') === 'connected') {
      setCalendarConnected(true)
      loadCalendarEvents()
      window.history.replaceState({}, '', '/')
    }
  }, [])

  async function loadSessions() {
    try {
      const data = await getSessions()
      setSessions(data)
    } catch (e) { console.error(e) }
  }

  async function checkCalendar() {
    try {
      const { authenticated } = await getCalendarStatus()
      setCalendarConnected(authenticated)
      if (authenticated) loadCalendarEvents()
    } catch (e) {}
  }

  async function loadCalendarEvents() {
    try {
      const { events } = await getEvents(7)
      setCalendarEvents(events)
    } catch (e) {}
  }

  async function handleConnectCalendar() {
    try {
      const { auth_url } = await getCalendarAuth()
      window.location.href = auth_url
    } catch (e) {
      alert('Could not start Google auth. Is the backend running and client_secrets.json configured?')
    }
  }

  async function handleNewSession() {
    try {
      const { session_id } = await createSession('New Mission')
      await loadSessions()
      const newSession = { id: session_id, title: 'New Mission', updated_at: new Date().toISOString() }
      setActiveSession(newSession)
      setMessages([])
    } catch (e) { console.error(e) }
  }

  async function handleSelectSession(session) {
    setActiveSession(session)
    try {
      const msgs = await getMessages(session.id)
      setMessages(msgs)
    } catch (e) { setMessages([]) }
  }

  async function handleDeleteSession(id) {
    if (!confirm('Delete this session?')) return
    try {
      await deleteSession(id)
      if (activeSession?.id === id) {
        setActiveSession(null)
        setMessages([])
      }
      loadSessions()
    } catch (e) {}
  }

  async function handleSend(text) {
    if (!text.trim()) return

    // Create session if none
    let session = activeSession
    if (!session) {
      try {
        const { session_id } = await createSession(text.slice(0, 40) || 'New Mission')
        session = { id: session_id, title: text.slice(0, 40), updated_at: new Date().toISOString() }
        setActiveSession(session)
        await loadSessions()
      } catch (e) { console.error(e); return }
    }

    const userMsg = { role: 'user', content: text, created_at: new Date().toISOString() }
    const updatedMsgs = [...messages, userMsg]
    setMessages(updatedMsgs)
    setIsLoading(true)

    // Save user message
    try { await saveMessage(session.id, 'user', text, module) } catch (e) {}

    // Build history for API (only role + content)
    const history = updatedMsgs.map(m => ({ role: m.role, content: m.content }))

    try {
      const { reply } = await sendMessage(history, module)
      const assistantMsg = { role: 'assistant', content: reply, created_at: new Date().toISOString() }
      setMessages(prev => [...prev, assistantMsg])

      // Save assistant message
      try { await saveMessage(session.id, 'assistant', reply, module) } catch (e) {}

      // Auto-update session title from first message
      if (messages.length === 0) {
        try { await updateSessionTitle(session.id, text.slice(0, 50)) } catch (e) {}
        loadSessions()
      }

      // Refresh calendar if calendar module active
      if (module === 'calendar' && calendarConnected) loadCalendarEvents()

    } catch (e) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `⚠️ Systems error, sir: ${e.response?.data?.detail || e.message}`,
        created_at: new Date().toISOString()
      }])
    }

    setIsLoading(false)
  }

  function handleModuleChange(mod) {
    setModule(mod)
    if (mod === 'calendar') setShowCalendar(true)
    else setShowCalendar(false)
  }

  return (
    <Layout>
      <Header calendarConnected={calendarConnected} onConnectCalendar={handleConnectCalendar} />
      <ModuleBar active={module} onChange={handleModuleChange} />
      <Main>
        <Sidebar
          sessions={sessions}
          activeSession={activeSession}
          onSelectSession={handleSelectSession}
          onNewSession={handleNewSession}
          onDeleteSession={handleDeleteSession}
          onQuickSend={text => { if (!activeSession) handleNewSession().then(() => handleSend(text)); else handleSend(text) }}
        />
        <ChatWindow
          messages={messages}
          isLoading={isLoading}
          onSend={handleSend}
          module={module}
        />
        {showCalendar && calendarConnected && (
          <CalendarPanel events={calendarEvents} onRefresh={loadCalendarEvents} />
        )}
      </Main>
    </Layout>
  )
}
