import React from 'react'
import styled, { keyframes } from 'styled-components'

const pulse = keyframes`
  0%,100% { box-shadow: 0 0 20px rgba(0,200,255,0.35), 0 0 50px rgba(0,200,255,0.2); }
  50% { box-shadow: 0 0 30px rgba(0,200,255,0.7), 0 0 80px rgba(0,200,255,0.3); }
`
const blink = keyframes`
  0%,100% { opacity:1; } 50% { opacity:0.3; }
`

const Wrap = styled.header`
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 24px;
  border-bottom: 1px solid var(--border);
  background: linear-gradient(180deg, rgba(4,20,40,0.97) 0%, rgba(2,11,20,0.85) 100%);
  backdrop-filter: blur(10px);
  flex-shrink: 0;
  position: relative; z-index: 10;
`
const Logo = styled.div`
  display: flex; align-items: center; gap: 14px;
`
const ArcReactor = styled.div`
  width: 42px; height: 42px; border-radius: 50%;
  background: radial-gradient(circle at 40% 35%, #fff 0%, #00c8ff 30%, #003a5c 70%, #001020 100%);
  animation: ${pulse} 2.5s ease-in-out infinite;
  position: relative;
  &::after {
    content: '';
    position: absolute; inset: 6px;
    border-radius: 50%;
    border: 1.5px solid rgba(255,255,255,0.4);
    box-shadow: 0 0 8px #00c8ff;
  }
`
const LogoText = styled.div`
  h1 {
    font-family: 'Rajdhani', sans-serif;
    font-size: 26px; font-weight: 700; letter-spacing: 6px;
    color: var(--accent); text-shadow: 0 0 20px var(--accent-glow);
  }
  p {
    font-size: 10px; letter-spacing: 3px; color: var(--text-dim);
    font-family: 'Share Tech Mono', monospace;
  }
`
const Right = styled.div`
  display: flex; align-items: center; gap: 16px;
`
const StatusPill = styled.div`
  display: flex; align-items: center; gap: 7px;
  padding: 5px 14px;
  border: 1px solid var(--border); border-radius: 20px;
  font-size: 11px; letter-spacing: 2px;
  font-family: 'Share Tech Mono', monospace;
  color: var(--text-dim);
  background: var(--accent-dim);
`
const Dot = styled.span`
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--success);
  box-shadow: 0 0 8px var(--success);
  animation: ${blink} 2s ease-in-out infinite;
  display: inline-block;
`
const CalBadge = styled.div`
  font-size: 10px; font-family: 'Share Tech Mono', monospace;
  letter-spacing: 1.5px;
  color: ${p => p.$connected ? 'var(--success)' : 'var(--text-dim)'};
  border: 1px solid ${p => p.$connected ? 'var(--success)' : 'var(--border)'};
  padding: 4px 10px; border-radius: 3px;
  cursor: ${p => p.$connected ? 'default' : 'pointer'};
  &:hover { border-color: var(--accent); color: var(--accent); }
`

export default function Header({ calendarConnected, onConnectCalendar }) {
  return (
    <Wrap>
      <Logo>
        <ArcReactor />
        <LogoText>
          <h1>JARVIS</h1>
          <p>Just A Rather Very Intelligent System</p>
        </LogoText>
      </Logo>
      <Right>
        <CalBadge $connected={calendarConnected} onClick={!calendarConnected ? onConnectCalendar : undefined}>
          {calendarConnected ? '📅 CALENDAR LINKED' : '📅 CONNECT CALENDAR'}
        </CalBadge>
        <StatusPill><Dot />ONLINE</StatusPill>
      </Right>
    </Wrap>
  )
}
