import React from 'react'
import styled from 'styled-components'
import { formatDistanceToNow } from 'date-fns'

const Wrap = styled.aside`
  width: 230px; flex-shrink: 0;
  border-right: 1px solid var(--border);
  background: rgba(4,15,28,0.7);
  display: flex; flex-direction: column;
  overflow: hidden;
`
const Top = styled.div`
  padding: 14px 12px 10px;
  border-bottom: 1px solid var(--border);
`
const NewBtn = styled.button`
  width: 100%; padding: 10px;
  background: var(--accent-dim);
  border: 1px solid var(--accent);
  border-radius: var(--radius);
  color: var(--accent);
  font-family: 'Rajdhani', sans-serif;
  font-size: 14px; letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.2s;
  &:hover { background: rgba(0,200,255,0.2); box-shadow: 0 0 14px rgba(0,200,255,0.2); }
`
const Label = styled.div`
  font-size: 9px; letter-spacing: 3px; color: var(--text-dim);
  font-family: 'Share Tech Mono', monospace;
  text-transform: uppercase;
  padding: 10px 12px 6px;
`
const Sessions = styled.div`
  flex: 1; overflow-y: auto; padding: 4px 8px;
`
const SessionItem = styled.div`
  padding: 9px 10px;
  border-radius: var(--radius);
  cursor: pointer;
  border: 1px solid ${p => p.$active ? 'var(--accent)' : 'transparent'};
  background: ${p => p.$active ? 'var(--accent-dim)' : 'transparent'};
  margin-bottom: 3px;
  transition: all 0.15s;
  display: flex; justify-content: space-between; align-items: flex-start;
  &:hover { border-color: var(--border); background: rgba(255,255,255,0.02); }
`
const STitle = styled.div`
  font-size: 12px;
  color: ${p => p.$active ? 'var(--accent)' : 'var(--text)'};
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  max-width: 150px;
`
const STime = styled.div`
  font-size: 9px; color: var(--text-dim);
  font-family: 'Share Tech Mono', monospace;
  margin-top: 3px;
`
const DelBtn = styled.button`
  background: none; border: none; cursor: pointer;
  color: var(--text-dim); font-size: 12px; padding: 0 2px;
  opacity: 0; transition: opacity 0.2s;
  ${SessionItem}:hover & { opacity: 1; }
  &:hover { color: var(--danger); }
`
const QuickSection = styled.div`
  border-top: 1px solid var(--border);
  padding: 8px;
`
const QuickBtn = styled.button`
  width: 100%; padding: 8px 10px;
  background: transparent; border: 1px solid transparent;
  border-radius: var(--radius); color: var(--text-dim);
  font-family: 'Exo 2', sans-serif; font-size: 11px;
  cursor: pointer; text-align: left; margin-bottom: 3px;
  transition: all 0.15s;
  display: flex; align-items: center; gap: 8px;
  &:hover { border-color: var(--border); color: var(--text); background: rgba(255,255,255,0.02); }
`

const QUICK_ACTIONS = [
  { icon: '🎯', label: "Today's priorities", msg: "Give me my top 3 priorities for today" },
  { icon: '💻', label: "Python automation", msg: "Write me a Python script to automate a repetitive Excel task" },
  { icon: '💪', label: "Workout plan", msg: "Give me a 4-week muscle gain workout plan" },
  { icon: '📖', label: "Vocab drill", msg: "Give me 5 advanced English vocabulary words with examples" },
  { icon: '💸', label: "Fiverr gig idea", msg: "Suggest a Fiverr gig title and description for data entry automation" },
  { icon: '🤖', label: "AI/ML roadmap", msg: "Create an AI/ML learning roadmap for a beginner, 3 months" },
]

export default function Sidebar({ sessions, activeSession, onSelectSession, onNewSession, onDeleteSession, onQuickSend }) {
  return (
    <Wrap>
      <Top>
        <NewBtn onClick={onNewSession}>+ NEW MISSION</NewBtn>
      </Top>
      <Label>Chat History</Label>
      <Sessions>
        {sessions.length === 0 && (
          <div style={{ padding: '12px', fontSize: '11px', color: 'var(--text-dim)', textAlign: 'center' }}>
            No sessions yet
          </div>
        )}
        {sessions.map(s => (
          <SessionItem key={s.id} $active={activeSession?.id === s.id} onClick={() => onSelectSession(s)}>
            <div style={{ overflow: 'hidden', flex: 1 }}>
              <STitle $active={activeSession?.id === s.id}>{s.title}</STitle>
              <STime>{formatDistanceToNow(new Date(s.updated_at), { addSuffix: true })}</STime>
            </div>
            <DelBtn onClick={e => { e.stopPropagation(); onDeleteSession(s.id) }}>✕</DelBtn>
          </SessionItem>
        ))}
      </Sessions>
      <QuickSection>
        <Label style={{ padding: '0 4px 6px' }}>Quick Actions</Label>
        {QUICK_ACTIONS.map(a => (
          <QuickBtn key={a.label} onClick={() => onQuickSend(a.msg)}>
            <span>{a.icon}</span>{a.label}
          </QuickBtn>
        ))}
      </QuickSection>
    </Wrap>
  )
}
