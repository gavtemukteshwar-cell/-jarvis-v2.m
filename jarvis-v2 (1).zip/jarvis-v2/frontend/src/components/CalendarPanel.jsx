import React, { useState } from 'react'
import styled from 'styled-components'
import { format } from 'date-fns'
import { createEvent, deleteEvent } from '../api/jarvis'

const Wrap = styled.div`
  width: 260px; flex-shrink: 0;
  border-left: 1px solid var(--border);
  background: rgba(4,15,28,0.7);
  display: flex; flex-direction: column;
  overflow: hidden;
`
const Head = styled.div`
  padding: 14px 14px 10px;
  border-bottom: 1px solid var(--border);
  font-family: 'Rajdhani', sans-serif;
  font-size: 15px; letter-spacing: 3px; color: var(--accent);
`
const Body = styled.div`
  flex: 1; overflow-y: auto; padding: 10px;
`
const EventCard = styled.div`
  background: rgba(0,200,255,0.04);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 10px 12px;
  margin-bottom: 8px;
  position: relative;
`
const ETitle = styled.div`
  font-size: 13px; color: var(--text); margin-bottom: 4px;
`
const ETime = styled.div`
  font-size: 10px; color: var(--accent);
  font-family: 'Share Tech Mono', monospace;
`
const DelEvt = styled.button`
  position: absolute; top: 8px; right: 8px;
  background: none; border: none; cursor: pointer;
  color: var(--text-dim); font-size: 11px;
  &:hover { color: var(--danger); }
`
const AddForm = styled.div`
  border-top: 1px solid var(--border);
  padding: 12px;
`
const Input = styled.input`
  width: 100%; padding: 8px 10px;
  background: var(--panel); border: 1px solid var(--border);
  border-radius: var(--radius); color: var(--text);
  font-family: 'Exo 2', sans-serif; font-size: 12px;
  margin-bottom: 7px; outline: none;
  &:focus { border-color: var(--accent); }
  &::placeholder { color: var(--text-dim); }
`
const AddBtn = styled.button`
  width: 100%; padding: 8px;
  background: var(--accent-dim); border: 1px solid var(--accent);
  border-radius: var(--radius); color: var(--accent);
  font-family: 'Rajdhani', sans-serif; font-size: 13px; letter-spacing: 2px;
  cursor: pointer;
  &:hover { background: rgba(0,200,255,0.2); }
`
const Empty = styled.div`
  text-align: center; color: var(--text-dim); font-size: 12px; padding: 20px 10px;
`
const Label = styled.div`
  font-size: 9px; letter-spacing: 3px; color: var(--text-dim);
  font-family: 'Share Tech Mono', monospace;
  text-transform: uppercase; margin-bottom: 8px;
`

function formatEventTime(iso) {
  try {
    return format(new Date(iso), 'MMM d, h:mm a')
  } catch {
    return iso
  }
}

export default function CalendarPanel({ events, onRefresh }) {
  const [form, setForm] = useState({ title: '', start: '', end: '' })
  const [loading, setLoading] = useState(false)

  async function handleCreate() {
    if (!form.title || !form.start || !form.end) return
    setLoading(true)
    try {
      await createEvent(form)
      setForm({ title: '', start: '', end: '' })
      onRefresh()
    } catch (e) {
      alert('Failed to create event: ' + e.message)
    }
    setLoading(false)
  }

  async function handleDelete(id) {
    if (!confirm('Delete this event?')) return
    try {
      await deleteEvent(id)
      onRefresh()
    } catch (e) {
      alert('Failed to delete: ' + e.message)
    }
  }

  return (
    <Wrap>
      <Head>📅 CALENDAR</Head>
      <Body>
        <Label>Upcoming Events</Label>
        {events.length === 0
          ? <Empty>No upcoming events, sir.</Empty>
          : events.map(e => (
            <EventCard key={e.id}>
              <ETitle>{e.title}</ETitle>
              <ETime>{formatEventTime(e.start)}</ETime>
              {e.location && <ETime style={{ color: 'var(--text-dim)' }}>📍 {e.location}</ETime>}
              <DelEvt onClick={() => handleDelete(e.id)}>✕</DelEvt>
            </EventCard>
          ))
        }
      </Body>
      <AddForm>
        <Label>Add Event</Label>
        <Input
          placeholder="Event title"
          value={form.title}
          onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
        />
        <Input
          type="datetime-local"
          value={form.start}
          onChange={e => setForm(p => ({ ...p, start: e.target.value }))}
          style={{ marginBottom: 7 }}
        />
        <Input
          type="datetime-local"
          value={form.end}
          onChange={e => setForm(p => ({ ...p, end: e.target.value }))}
        />
        <AddBtn onClick={handleCreate} disabled={loading}>
          {loading ? 'CREATING...' : '+ ADD EVENT'}
        </AddBtn>
      </AddForm>
    </Wrap>
  )
}
