import React from 'react'
import styled from 'styled-components'

const Bar = styled.div`
  display: flex; gap: 6px; padding: 8px 16px;
  border-bottom: 1px solid var(--border);
  background: rgba(4,15,28,0.8);
  flex-shrink: 0; overflow-x: auto;
  &::-webkit-scrollbar { height: 3px; }
`
const Btn = styled.button`
  padding: 5px 14px;
  border: 1px solid ${p => p.$active ? 'var(--accent)' : 'var(--border)'};
  border-radius: var(--radius);
  background: ${p => p.$active ? 'var(--accent-dim)' : 'transparent'};
  color: ${p => p.$active ? 'var(--accent)' : 'var(--text-dim)'};
  font-family: 'Share Tech Mono', monospace;
  font-size: 10px; letter-spacing: 1.5px;
  cursor: pointer; white-space: nowrap;
  transition: all 0.2s; text-transform: uppercase;
  &:hover { border-color: var(--accent); color: var(--accent); background: var(--accent-dim); }
`

const MODULES = [
  { id: '', label: '⚡ General' },
  { id: 'code', label: '💻 Code' },
  { id: 'research', label: '🔍 Research' },
  { id: 'fitness', label: '💪 Fitness' },
  { id: 'freelance', label: '💼 Freelance' },
  { id: 'tasks', label: '📋 Tasks' },
  { id: 'learning', label: '📚 Learning' },
  { id: 'calendar', label: '📅 Calendar' },
  { id: 'voice', label: '🎙️ Voice' },
]

export default function ModuleBar({ active, onChange }) {
  return (
    <Bar>
      {MODULES.map(m => (
        <Btn key={m.id} $active={active === m.id} onClick={() => onChange(m.id)}>
          {m.label}
        </Btn>
      ))}
    </Bar>
  )
}
