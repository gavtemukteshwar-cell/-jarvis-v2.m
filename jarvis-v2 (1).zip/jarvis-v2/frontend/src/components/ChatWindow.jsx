import React, { useEffect, useRef, useState } from 'react'
import styled, { keyframes } from 'styled-components'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { format } from 'date-fns'

const Wrap = styled.div`
  flex: 1; display: flex; flex-direction: column; overflow: hidden;
`
const Messages = styled.div`
  flex: 1; overflow-y: auto; padding: 20px 24px;
  display: flex; flex-direction: column; gap: 16px;
`
const fadeUp = keyframes`
  from { opacity:0; transform:translateY(10px); }
  to { opacity:1; transform:translateY(0); }
`
const Msg = styled.div`
  display: flex; gap: 12px; animation: ${fadeUp} 0.3s ease;
  flex-direction: ${p => p.$user ? 'row-reverse' : 'row'};
  align-self: ${p => p.$user ? 'flex-end' : 'flex-start'};
  max-width: 780px;
`
const Avatar = styled.div`
  width: 36px; height: 36px; border-radius: var(--radius);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; border: 1px solid;
  font-family: 'Rajdhani', sans-serif; font-weight: 700;
  border-color: ${p => p.$user ? 'var(--gold)' : 'var(--accent)'};
  background: ${p => p.$user ? 'rgba(240,180,41,0.1)' : 'var(--accent-dim)'};
  color: ${p => p.$user ? 'var(--gold)' : 'var(--accent)'};
  font-size: ${p => p.$user ? '16px' : '12px'};
  letter-spacing: 1px;
`
const Bubble = styled.div`
  padding: 12px 16px;
  border-radius: var(--radius);
  border: 1px solid ${p => p.$user ? 'rgba(0,170,255,0.25)' : 'var(--border)'};
  background: ${p => p.$user ? 'rgba(0,170,255,0.07)' : 'rgba(7,24,40,0.85)'};
  max-width: calc(100% - 50px);
`
const Meta = styled.div`
  font-size: 10px; color: var(--text-dim);
  font-family: 'Share Tech Mono', monospace;
  margin-top: 5px; letter-spacing: 1px;
`
const bounce = keyframes`
  0%,60%,100% { transform:translateY(0); opacity:0.4; }
  30% { transform:translateY(-6px); opacity:1; }
`
const TypingDot = styled.span`
  width: 6px; height: 6px; border-radius: 50%;
  background: var(--accent); display: inline-block; margin: 0 2px;
  animation: ${bounce} 1.2s ease-in-out infinite;
  &:nth-child(2) { animation-delay: 0.2s; }
  &:nth-child(3) { animation-delay: 0.4s; }
`
const InputArea = styled.div`
  padding: 14px 20px 18px;
  border-top: 1px solid var(--border);
  background: rgba(4,15,28,0.9);
  backdrop-filter: blur(10px);
`
const InputWrap = styled.div`
  display: flex; gap: 10px; align-items: flex-end;
  background: var(--panel); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 10px 14px;
  transition: border-color 0.2s, box-shadow 0.2s;
  &:focus-within {
    border-color: var(--accent);
    box-shadow: 0 0 20px rgba(0,200,255,0.1);
  }
`
const TextArea = styled.textarea`
  flex: 1; background: transparent; border: none; outline: none;
  color: var(--text); font-family: 'Exo 2', sans-serif; font-size: 14px;
  resize: none; max-height: 120px; line-height: 1.5;
  &::placeholder { color: var(--text-dim); }
`
const SendBtn = styled.button`
  width: 38px; height: 38px; border-radius: var(--radius);
  border: 1px solid var(--accent); background: var(--accent-dim);
  color: var(--accent); cursor: pointer; font-size: 16px;
  display: flex; align-items: center; justify-content: center;
  transition: all 0.2s; flex-shrink: 0;
  &:hover:not(:disabled) { background: var(--accent); color: var(--bg); box-shadow: 0 0 15px var(--accent-glow); }
  &:disabled { opacity: 0.4; cursor: not-allowed; }
`
const Hint = styled.div`
  font-size: 10px; color: var(--text-dim);
  font-family: 'Share Tech Mono', monospace;
  margin-top: 6px; letter-spacing: 1px; text-align: center;
`
const Welcome = styled.div`
  background: rgba(7,24,40,0.7);
  border: 1px solid var(--border); border-radius: var(--radius);
  padding: 22px 26px; max-width: 560px;
  h2 { font-family:'Rajdhani',sans-serif; font-size:20px; letter-spacing:3px; color:var(--accent); margin-bottom:8px; }
  p { font-size:13px; color:var(--text-dim); line-height:1.7; }
`
const Grid = styled.div`
  display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 14px;
`
const Cap = styled.div`
  padding: 8px 10px; border: 1px solid var(--border); border-radius: var(--radius);
  font-size: 11px; color: var(--text-dim);
  display: flex; align-items: center; gap: 7px;
`

export default function ChatWindow({ messages, isLoading, onSend, module }) {
  const endRef = useRef(null)
  const [input, setInput] = useState('')
  const textRef = useRef(null)

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages, isLoading])

  function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit() }
  }

  function submit() {
    const txt = input.trim()
    if (!txt || isLoading) return
    setInput('')
    if (textRef.current) textRef.current.style.height = 'auto'
    onSend(txt)
  }

  function autoResize(e) {
    e.target.style.height = 'auto'
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
  }

  return (
    <Wrap>
      <Messages>
        {messages.length === 0 && (
          <Msg>
            <Avatar>J</Avatar>
            <div>
              <Bubble>
                <Welcome>
                  <h2>JARVIS ONLINE</h2>
                  <p>Good day, sir. All systems operational. How may I serve you today?</p>
                  <Grid>
                    {['💻 Code & Debug','🔍 Research','💪 Fitness Plans','💼 Freelance','📚 Learning','📅 Calendar'].map(c => (
                      <Cap key={c}><span>{c.slice(0,2)}</span>{c.slice(3)}</Cap>
                    ))}
                  </Grid>
                </Welcome>
              </Bubble>
              <Meta>JARVIS · Ready</Meta>
            </div>
          </Msg>
        )}

        {messages.map((m, i) => (
          <Msg key={i} $user={m.role === 'user'}>
            <Avatar $user={m.role === 'user'}>{m.role === 'user' ? '👤' : 'J'}</Avatar>
            <div>
              <Bubble $user={m.role === 'user'}>
                {m.role === 'user'
                  ? <span style={{ fontSize: 14, lineHeight: 1.6 }}>{m.content}</span>
                  : <div className="markdown-body"><ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown></div>
                }
              </Bubble>
              <Meta style={{ textAlign: m.role === 'user' ? 'right' : 'left' }}>
                {m.role === 'user' ? 'You' : 'JARVIS'} · {m.created_at ? format(new Date(m.created_at), 'h:mm a') : format(new Date(), 'h:mm a')}
              </Meta>
            </div>
          </Msg>
        ))}

        {isLoading && (
          <Msg>
            <Avatar>J</Avatar>
            <div>
              <Bubble style={{ padding: '14px 18px' }}>
                <TypingDot/><TypingDot/><TypingDot/>
              </Bubble>
            </div>
          </Msg>
        )}
        <div ref={endRef} />
      </Messages>

      <InputArea>
        <InputWrap>
          <TextArea
            ref={textRef}
            placeholder="Speak your command, sir..."
            rows={1}
            value={input}
            onChange={e => { setInput(e.target.value); autoResize(e) }}
            onKeyDown={handleKey}
          />
          <SendBtn onClick={submit} disabled={isLoading || !input.trim()}>➤</SendBtn>
        </InputWrap>
        <Hint>ENTER to send · SHIFT+ENTER new line · Module: {module || 'General'}</Hint>
      </InputArea>
    </Wrap>
  )
}
