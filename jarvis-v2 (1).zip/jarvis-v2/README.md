# JARVIS v2.0 — Personal AI Assistant

Full-stack AI assistant with React frontend, FastAPI backend, SQLite chat history, and Google Calendar integration.

---

## Project Structure

```
jarvis-v2/
├── frontend/          ← React + Vite app
│   └── src/
│       ├── App.jsx
│       ├── components/
│       │   ├── Header.jsx
│       │   ├── Sidebar.jsx
│       │   ├── ModuleBar.jsx
│       │   ├── ChatWindow.jsx
│       │   └── CalendarPanel.jsx
│       └── api/jarvis.js
│
├── backend/           ← Python FastAPI
│   ├── main.py
│   ├── requirements.txt
│   ├── routes/
│   │   ├── jarvis.py      ← Claude AI proxy
│   │   ├── chat.py        ← Chat history (SQLite)
│   │   └── calendar.py    ← Google Calendar
│   └── db/database.py
│
└── README.md
```

---

## Step 1 — Backend Setup

### Install Python dependencies

```bash
cd backend
pip install -r requirements.txt
```

### Set environment variables

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Edit `.env`:

```
ANTHROPIC_API_KEY=your_anthropic_api_key_here
GOOGLE_REDIRECT_URI=http://localhost:8000/api/calendar/callback
```

Get your Anthropic API key from: https://console.anthropic.com

### Start the backend

```bash
cd backend
python main.py
```

Backend runs at: http://localhost:8000
API docs at: http://localhost:8000/docs

---

## Step 2 — Google Calendar Setup

### Create Google OAuth credentials

1. Go to https://console.cloud.google.com
2. Create a new project (or use existing)
3. Go to **APIs & Services → Library**
4. Search and enable **Google Calendar API**
5. Go to **APIs & Services → Credentials**
6. Click **Create Credentials → OAuth 2.0 Client ID**
7. Application type: **Web application**
8. Add authorized redirect URI: `http://localhost:8000/api/calendar/callback`
9. Click **Create**
10. Download the JSON file and save it as `backend/client_secrets.json`

### Connect your Google account

1. Start the backend (see Step 1)
2. Open browser: http://localhost:8000/api/calendar/auth
3. Follow the Google login flow
4. You'll be redirected back to the app with calendar connected

---

## Step 3 — Frontend Setup

### Install dependencies

```bash
cd frontend
npm install
```

### Start the frontend

```bash
npm run dev
```

Frontend runs at: http://localhost:5173

---

## Running the Full App

Open **two terminals**:

**Terminal 1 (backend):**
```bash
cd backend && python main.py
```

**Terminal 2 (frontend):**
```bash
cd frontend && npm run dev
```

Open http://localhost:5173 in your browser.

---

## Deploying Online

### Frontend → GitHub Pages or Vercel

```bash
cd frontend
npm run build
# Upload the dist/ folder to GitHub Pages or Vercel
```

For Vercel:
```bash
npm install -g vercel
vercel --prod
```

Set environment variable in Vercel: `VITE_API_URL=https://your-backend-url.com`

### Backend → Railway (recommended, free tier)

1. Go to https://railway.app
2. Click **New Project → Deploy from GitHub**
3. Connect your repo, select the `backend/` folder
4. Add environment variables:
   - `ANTHROPIC_API_KEY`
   - `GOOGLE_REDIRECT_URI=https://your-backend.railway.app/api/calendar/callback`
5. Railway auto-detects Python and deploys

### Backend → Render (alternative)

1. Go to https://render.com
2. New → Web Service → Connect GitHub repo
3. Root directory: `backend`
4. Build command: `pip install -r requirements.txt`
5. Start command: `uvicorn main:app --host 0.0.0.0 --port 10000`
6. Add environment variables in dashboard

---

## Features

- **JARVIS AI** — Powered by Claude, with full personality and 8 modules
- **Chat History** — All conversations saved to SQLite, persistent across sessions
- **Session Management** — Create, switch, delete sessions from sidebar
- **Google Calendar** — View, create, delete events from the app
- **8 Modules** — General, Code, Research, Fitness, Freelance, Tasks, Learning, Voice
- **Quick Actions** — One-click shortcuts in the sidebar

---

## Troubleshooting

**Backend won't start:** Make sure you're in the `backend/` directory and ran `pip install -r requirements.txt`

**Google Calendar auth fails:** Check that `client_secrets.json` is in the `backend/` folder and the redirect URI matches exactly

**CORS errors:** Make sure both frontend and backend are running; the Vite proxy handles `/api` → `localhost:8000`

**Claude API errors:** Check your `ANTHROPIC_API_KEY` in the `.env` file
