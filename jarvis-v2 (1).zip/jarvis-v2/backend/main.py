from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
import uvicorn

from routes import chat, calendar, jarvis

app = FastAPI(title="JARVIS Backend", version="2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat.router, prefix="/api/chat", tags=["Chat History"])
app.include_router(calendar.router, prefix="/api/calendar", tags=["Google Calendar"])
app.include_router(jarvis.router, prefix="/api/jarvis", tags=["JARVIS AI"])

@app.get("/")
def root():
    return {"status": "JARVIS backend online", "version": "2.0"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
