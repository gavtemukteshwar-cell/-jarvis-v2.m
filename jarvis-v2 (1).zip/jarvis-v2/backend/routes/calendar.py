from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from typing import Optional, List
import os
import json
from datetime import datetime, timedelta

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from google.auth.transport.requests import Request as GRequest

router = APIRouter()

SCOPES = ["https://www.googleapis.com/auth/calendar"]
CLIENT_SECRETS_FILE = os.path.join(os.path.dirname(__file__), "..", "client_secrets.json")
TOKEN_FILE = os.path.join(os.path.dirname(__file__), "..", "token.json")
REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI", "http://localhost:8000/api/calendar/callback")

def get_credentials():
    if not os.path.exists(TOKEN_FILE):
        return None
    creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(GRequest())
        with open(TOKEN_FILE, "w") as f:
            f.write(creds.to_json())
    return creds if creds and creds.valid else None

def get_service():
    creds = get_credentials()
    if not creds:
        raise HTTPException(status_code=401, detail="Not authenticated with Google. Visit /api/calendar/auth first.")
    return build("calendar", "v3", credentials=creds)

# ── AUTH ──
@router.get("/auth")
def start_auth():
    if not os.path.exists(CLIENT_SECRETS_FILE):
        raise HTTPException(
            status_code=500,
            detail="client_secrets.json not found. See README for Google OAuth setup."
        )
    flow = Flow.from_client_secrets_file(CLIENT_SECRETS_FILE, scopes=SCOPES, redirect_uri=REDIRECT_URI)
    auth_url, _ = flow.authorization_url(prompt="consent", access_type="offline")
    return {"auth_url": auth_url}

@router.get("/callback")
def auth_callback(code: str, state: Optional[str] = None):
    flow = Flow.from_client_secrets_file(CLIENT_SECRETS_FILE, scopes=SCOPES, redirect_uri=REDIRECT_URI)
    flow.fetch_token(code=code)
    creds = flow.credentials
    with open(TOKEN_FILE, "w") as f:
        f.write(creds.to_json())
    return RedirectResponse(url="http://localhost:5173?calendar=connected")

@router.get("/status")
def auth_status():
    creds = get_credentials()
    return {"authenticated": creds is not None}

# ── EVENTS ──
@router.get("/events")
def get_events(days: int = 7):
    service = get_service()
    now = datetime.utcnow().isoformat() + "Z"
    end = (datetime.utcnow() + timedelta(days=days)).isoformat() + "Z"
    result = service.events().list(
        calendarId="primary",
        timeMin=now,
        timeMax=end,
        maxResults=20,
        singleEvents=True,
        orderBy="startTime"
    ).execute()
    events = result.get("items", [])
    return {"events": [
        {
            "id": e["id"],
            "title": e.get("summary", "No title"),
            "start": e["start"].get("dateTime", e["start"].get("date")),
            "end": e["end"].get("dateTime", e["end"].get("date")),
            "description": e.get("description", ""),
            "location": e.get("location", ""),
        }
        for e in events
    ]}

class EventCreate(BaseModel):
    title: str
    start: str        # ISO format e.g. "2025-01-15T10:00:00"
    end: str          # ISO format
    description: Optional[str] = ""
    location: Optional[str] = ""
    timezone: Optional[str] = "Asia/Kolkata"

@router.post("/events")
def create_event(data: EventCreate):
    service = get_service()
    event = {
        "summary": data.title,
        "description": data.description,
        "location": data.location,
        "start": {"dateTime": data.start, "timeZone": data.timezone},
        "end": {"dateTime": data.end, "timeZone": data.timezone},
    }
    created = service.events().insert(calendarId="primary", body=event).execute()
    return {"status": "created", "event_id": created["id"], "link": created.get("htmlLink")}

@router.delete("/events/{event_id}")
def delete_event(event_id: str):
    service = get_service()
    service.events().delete(calendarId="primary", eventId=event_id).execute()
    return {"status": "deleted"}

@router.get("/today")
def get_today():
    service = get_service()
    now = datetime.utcnow()
    start = now.replace(hour=0, minute=0, second=0).isoformat() + "Z"
    end = now.replace(hour=23, minute=59, second=59).isoformat() + "Z"
    result = service.events().list(
        calendarId="primary",
        timeMin=start,
        timeMax=end,
        singleEvents=True,
        orderBy="startTime"
    ).execute()
    events = result.get("items", [])
    return {"events": [
        {
            "id": e["id"],
            "title": e.get("summary", "No title"),
            "start": e["start"].get("dateTime", e["start"].get("date")),
            "end": e["end"].get("dateTime", e["end"].get("date")),
        }
        for e in events
    ], "count": len(events)}
