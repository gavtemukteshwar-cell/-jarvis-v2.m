from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import uuid
from db.database import get_db

router = APIRouter()

class MessageIn(BaseModel):
    session_id: str
    role: str
    content: str
    module: Optional[str] = ""

class SessionCreate(BaseModel):
    title: Optional[str] = "New Conversation"

@router.post("/sessions")
def create_session(data: SessionCreate):
    session_id = str(uuid.uuid4())
    conn = get_db()
    conn.execute(
        "INSERT INTO sessions (id, title) VALUES (?, ?)",
        (session_id, data.title)
    )
    conn.commit()
    conn.close()
    return {"session_id": session_id, "title": data.title}

@router.get("/sessions")
def get_sessions():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM sessions ORDER BY updated_at DESC LIMIT 50"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@router.delete("/sessions/{session_id}")
def delete_session(session_id: str):
    conn = get_db()
    conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
    conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted"}

@router.post("/messages")
def save_message(msg: MessageIn):
    conn = get_db()
    conn.execute(
        "INSERT INTO messages (session_id, role, content, module) VALUES (?, ?, ?, ?)",
        (msg.session_id, msg.role, msg.content, msg.module)
    )
    conn.execute(
        "UPDATE sessions SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (msg.session_id,)
    )
    conn.commit()
    conn.close()
    return {"status": "saved"}

@router.get("/messages/{session_id}")
def get_messages(session_id: str):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM messages WHERE session_id = ? ORDER BY created_at ASC",
        (session_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@router.patch("/sessions/{session_id}/title")
def update_title(session_id: str, data: dict):
    conn = get_db()
    conn.execute(
        "UPDATE sessions SET title = ? WHERE id = ?",
        (data.get("title", "Conversation"), session_id)
    )
    conn.commit()
    conn.close()
    return {"status": "updated"}
